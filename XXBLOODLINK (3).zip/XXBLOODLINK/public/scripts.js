document.addEventListener("DOMContentLoaded", () => {
    const loginForm = document.getElementById("loginForm");
    const registrationForm = document.getElementById("createUserForm");
    const requestPasswordResetForm = document.getElementById("requestPasswordResetForm");
    const resetPasswordForm = document.getElementById("resetPasswordForm");
    const donationForm = document.getElementById("donationForm");

    function displayMessage(message, isError = false) {
        let messageArea = document.getElementById("message");

        if (!messageArea) {
            messageArea = document.createElement("div");
            messageArea.id = "message";
            document.body.insertBefore(messageArea, document.body.firstChild);
        }

        messageArea.textContent = message;
        messageArea.style.color = isError ? "red" : "green";
        messageArea.style.fontWeight = "bold";
    }

    function showLoadingIndicator(isLoading) {
        const loadingIndicator = document.getElementById("loadingIndicator");
        if (loadingIndicator) {
            loadingIndicator.style.display = isLoading ? "block" : "none";
        }
    }

    if (registrationForm) {
        registrationForm.addEventListener("submit", async (event) => {
            event.preventDefault();
            console.log("🚀 Registration Form Submitted!");

            const submitButton = registrationForm.querySelector("button[type='submit']");
            submitButton.disabled = true;

            const formData = {
                name: document.getElementById("name").value.trim(),
                phone: document.getElementById("phone").value.trim(),
                email: document.getElementById("email").value.trim(),
                password: document.getElementById("password").value,
                blood_type: document.getElementById("blood_type").value,
                location: document.getElementById("location").value.trim(),
                role: document.getElementById("role").value
            };

            if (Object.values(formData).some(value => !value)) {
                displayMessage("❌ Please fill in all fields.", true);
                submitButton.disabled = false;
                return;
            }

            showLoadingIndicator(true);

            try {
                const response = await fetch("http://localhost:5500/api/users", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify(formData),
                });

                let result;
                try {
                    result = await response.json();
                } catch {
                    throw new Error("❌ Invalid response from server.");
                }

                if (!response.ok) {
                    throw new Error(result.error || "❌ Registration failed.");
                }

                console.log("✅ Success:", result);
                displayMessage("✅ Account created successfully! Redirecting...", false);

                setTimeout(() => {
                    window.location.href = "dashboard.html";
                }, 2000);

            } catch (error) {
                console.error("🚨 Registration Error:", error);
                displayMessage(error.message, true);
            } finally {
                showLoadingIndicator(false);
                submitButton.disabled = false;
            }
        });
    }
}); 
