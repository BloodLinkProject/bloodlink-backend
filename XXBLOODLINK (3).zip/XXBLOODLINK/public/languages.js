// Main translation function
async function applyTranslations() {
    // Set default language if none exists
    if (!localStorage.getItem("language")) {
        localStorage.setItem("language", "en");
    }
    
    const lang = localStorage.getItem("language");
    console.log(`Applying ${lang} translations`);

    try {
        let translations;
        
        // Try to get translations from either embedded or JSON file
        if (typeof window.translations !== 'undefined') {
            translations = window.translations;
            console.log("Using embedded translations");
        } else {
            console.log("Fetching translations from languages.json");
            const response = await fetch(`languages.json?t=${Date.now()}`);
            
            if (!response.ok) {
                throw new Error(`HTTP ${response.status} loading translations`);
            }
            
            translations = await response.json();
        }

        // Apply translations to different element types
        translateRegularElements(translations, lang);
        translatePlaceholders(translations, lang);
        translateSelectOptions(translations, lang);
        translatePageTitle(translations, lang);

        console.log("Translations applied successfully");
    } catch (error) {
        console.error("Translation error:", error);
        localStorage.setItem("language", "en");
        location.reload();
    }
}

// Helper function to get translation with fallback
function getTranslation(translations, lang, key) {
    return translations[lang]?.[key] || translations.en?.[key];
}

// Translate regular elements
function translateRegularElements(translations, lang) {
    document.querySelectorAll("[data-translate]").forEach(element => {
        if (element.hasAttribute("data-translate-placeholder")) return;
        
        const key = element.getAttribute("data-translate");
        const translation = getTranslation(translations, lang, key);
        
        if (translation) {
            if (element.hasAttribute("title")) {
                element.title = translation;
            } else {
                element.textContent = translation;
            }
        }
    });
}

// Translate placeholder elements
function translatePlaceholders(translations, lang) {
    document.querySelectorAll("[data-translate-placeholder]").forEach(element => {
        const key = element.getAttribute("data-translate-placeholder");
        const translation = getTranslation(translations, lang, key);
        
        if (translation) {
            element.placeholder = translation;
        }
    });
}

// Translate select options
function translateSelectOptions(translations, lang) {
    document.querySelectorAll("option[data-translate]").forEach(option => {
        const key = option.getAttribute("data-translate");
        const translation = getTranslation(translations, lang, key);
        if (translation) option.textContent = translation;
    });
}

// Translate page title
function translatePageTitle(translations, lang) {
    const titleElement = document.querySelector("title");
    if (titleElement && titleElement.hasAttribute("data-translate")) {
        const key = titleElement.getAttribute("data-translate");
        const translation = getTranslation(translations, lang, key);
        if (translation) document.title = translation;
    }
}

// Language switcher function
function changeLanguage(lang) {
    localStorage.setItem("language", lang);
    location.reload();
}

// Initialize translations when DOM is loaded
document.addEventListener("DOMContentLoaded", applyTranslations);