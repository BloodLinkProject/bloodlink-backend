const nodemailer = require("nodemailer");

async function sendVerificationEmail(email, userId) {
    let transporter = nodemailer.createTransport({
        service: "gmail",
        auth: {
            user: process.env.EMAIL_USER,  // Replace with real email
            pass: process.env.EMAIL_PASS   // Replace with real password
        }
    });

    let mailOptions = {
        from: process.env.EMAIL_USER,
        to: email,
        subject: "Email Verification",
        text: `Click this link to verify your email: http://192.168.8.14:5500/verify-email/${userId}`
    };

    try {
        await transporter.sendMail(mailOptions);
        console.log(`✅ Verification email sent to ${email}`);
    } catch (error) {
        console.error("🚨 Error sending verification email:", error);
    }
}

module.exports = { sendVerificationEmail };
