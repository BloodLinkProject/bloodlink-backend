const nodemailer = require("nodemailer");
require("dotenv").config();

async function sendDonationReminder(userEmail, userId, message) {
    let transporter = nodemailer.createTransport({
        service: "gmail",
        auth: {
            user: "your-email@gmail.com",
            pass: "your-password",
        },
    });

    let mailOptions = {
        from: "your-email@gmail.com",
        to: userEmail,
        subject: "Donation Reminder",
        text: message,
    };

    try {
        await transporter.sendMail(mailOptions);
        console.log("Email sent successfully!");

        // Store notification in database
        let sql = "INSERT INTO notifications (user_id, message) VALUES (?, ?)";
        db.query(sql, [userId, message], (err, result) => {
            if (err) throw err;
            console.log("Notification stored in DB.");
        });

    } catch (error) {
        console.error("Error sending email:", error);
    }
}

module.exports = { sendDonationReminder };
